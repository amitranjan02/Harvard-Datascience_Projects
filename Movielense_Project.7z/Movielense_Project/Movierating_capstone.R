library(tidyverse)
library(caret)

# Note: this process could take a couple of minutes

if(!require(tidyverse)) install.packages("tidyverse", repos = "http://cran.us.r-project.org")
if(!require(caret)) install.packages("caret", repos = "http://cran.us.r-project.org")

# MovieLens 10M dataset:
# https://grouplens.org/datasets/movielens/10m/
# http://files.grouplens.org/datasets/movielens/ml-10m.zip

dl <- tempfile()
download.file("http://files.grouplens.org/datasets/movielens/ml-10m.zip", dl)

ratings <- read.table(text = gsub("::", "\t", readLines(unzip(dl, "ml-10M100K/ratings.dat"))),
                      col.names = c("userId", "movieId", "rating", "timestamp"))

movies <- str_split_fixed(readLines(unzip(dl, "ml-10M100K/movies.dat")), "\\::", 3)
colnames(movies) <- c("movieId", "title", "genres")
movies <- as.data.frame(movies) %>% mutate(movieId = as.numeric(levels(movieId))[movieId],
                                           title = as.character(title),
                                           genres = as.character(genres))

movielens <- left_join(ratings, movies, by = "movieId")

# Validation set will be 10% of MovieLens data

set.seed(1) # if using R 3.6.0: set.seed(1, sample.kind = "Rounding")
test_index <- createDataPartition(y = movielens$rating, times = 1, p = 0.1, list = FALSE)
edx <- movielens[-test_index,]
temp <- movielens[test_index,]

# Make sure userId and movieId in validation set are also in edx set

validation <- temp %>% 
  semi_join(edx, by = "movieId") %>%
  semi_join(edx, by = "userId")

# Add rows removed from validation set back into edx set

removed <- anti_join(temp, validation)
edx <- rbind(edx, removed)

rm(dl, ratings, movies, test_index, temp, movielens, removed)
#####number of ratings of Drama,Comedy,Thriller & Romance
edx%>%head(n=5)
edx%>%select(genres,rating)%>%group_by(genres)%>%summarise(n=n())%>%filter(str_detect(genres,"Drama"))%>%mutate(total=sum(n))
edx%>%select(genres,rating)%>%group_by(genres)%>%summarise(n=n())%>%filter(str_detect(genres,"Comedy"))%>%mutate(total=sum(n))
edx%>%select(genres,rating)%>%group_by(genres)%>%summarise(n=n())%>%filter(str_detect(genres,"Thriller"))%>%mutate(total=sum(n))
edx%>%select(genres,rating)%>%group_by(genres)%>%summarise(n=n())%>%filter(str_detect(genres,"Romance"))%>%mutate(total=sum(n))

#Which movie has the greatest number of ratings?
edx%>%select(title,rating)%>%group_by(title)%>%summarise(n=n())%>%filter(str_detect(title,"Forrest Gump|Jurassic Park|Pulp Fiction|The Shawshank Redemption|Speed 2: Cruise Control"))

#What are the five most given ratings in order from most to least?   
edx%>%select(rating)%>%group_by(rating)%>%summarise(n=n())%>%arrange(desc(n))
edx%>%head(n=5)

################### Exploratory Analysis ##################################
#converting formats#
head(edx)
sapply(edx,class)
class(edx$timestamp)
edx$timestamp<- as.POSIXct(as.numeric(edx$timestamp), origin='1970-01-01',tz="UTC")         
class(edx$timestamp)
#Check the outcome/y is normally distributed#
hist(edx$rating)
hist(validation$rating)
ggplot(edx, aes(x = rating)) + 
  geom_density(trim = TRUE) + 
  geom_density(data = validation, trim = TRUE, col = "red")
edx%>%select(rating,title)%>%group_by(rating)%>%summarize(n=n())%>%ggplot(aes(x=rating,y=n))+geom_bar(stat ="identity")
edx%>%select(rating)%>%group_by(rating)%>%summarize(n=n())%>%ggplot(aes(rating,n))+geom_density(stat = "identity")+geom_smooth()
####### Predicition######
#As the data set is huge, the following methods are followed as taught by Prof. in the video lectures and ref:Datascience book

#Simple Avg method
muhat<-mean(edx$rating)
naive_rmse<-RMSE(validation$rating,muhat)
naive_rmse
rmse_results<-data_frame(method="Simple average method", RMSE=naive_rmse)

# Incuding movie effect
mu<-mean(edx$rating)
movie_avgs<-edx%>%group_by(movieId)%>%summarise(b_i=mean(rating-mu))
movie_avgs%>%qplot(b_i,geom="histogram", bins=10,data=.,colour=I("blue"))
predicted_ratings<-mu+validation%>%left_join(movie_avgs,by='movieId')%>%
  pull(b_i)
model_1_rmse<-RMSE(predicted_ratings,validation$rating)
rmse_results<-bind_rows(rmse_results,data_frame(method="Movie Effect Model", RMSE=model_1_rmse))
rmse_results

#Usereffect Model
head(predicted_ratings)
edx%>%group_by(userId)%>%summarise(b_u=mean(rating))%>%
  filter(n()>100)%>%ggplot(aes(b_u))+geom_histogram(bins = 30,color="black")
user_avgs<-edx%>%left_join(movie_avgs,by='movieId')%>%
  group_by(userId)%>%summarise(b_u=mean(rating-mu-b_i))

predicted_ratings<-validation%>%left_join(movie_avgs,by='movieId')%>%
  left_join(user_avgs, by='userId')
predicted_ratings<-predicted_ratings%>%mutate(pred=rating+b_i+b_u)%>%pull(pred)

model2_rmse<-RMSE(predicted_ratings,validation$rating)
rmse_results<-bind_rows(rmse_results,data_frame(method="Movie+Usereffect Model",RMSE=model2_rmse))
rmse_results
####

save.image('movielenseproj.rdata')
dir()
  
)